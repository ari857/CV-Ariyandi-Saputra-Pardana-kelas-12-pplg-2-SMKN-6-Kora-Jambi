<?php
$database= mysqli_connect('localhost','root','','toko');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $kode = $_POST ["nama"];
    $nama = $_POST ["jenis_kelamin"];
    $jenis_kelamin = $_POST ["alamat"];
    $alamat = $_POST ["no_tlpn"];
    $jumlah = $_POST ["skil"];


    $tambah = "INSERT INTO barang VALUE
    ('','$kode','$nama','$jenis_kelamin','$alamat','$jumlah ')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}

function tambah2 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $alamat = $_POST ["alamat"];
    $tambah = "INSERT INTO e_hotel VALUE
    ('','$nama','$jenis_kelamin','$alamat')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}

function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM barang where no=$hapus");
    return mysqli_affected_rows($database);
}


?>