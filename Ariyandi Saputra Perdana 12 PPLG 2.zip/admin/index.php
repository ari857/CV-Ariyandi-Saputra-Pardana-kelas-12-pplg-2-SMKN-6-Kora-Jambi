<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM barang");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM barang WHERE
    nama like'%$Pencarian%'";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM barang');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">Website Tugas</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Profil</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="keluar.php"> Keluar </a></li>
        </ul>
    </div>
    <div class="konten">
<h1>Identitas</h1>  
<a href="tambah.php">Tambah</a>
<form action="" method="post">
    <input type="text" name="pencarian">
    <button type="submit" name="tombol">Cari</button>
</form>
<div class="tabel">
<table border="1" cellspadding="20" callspacing= "10">
    <tr class="tabel-header">
        <th>No</th>
        <th>Nama </th>
        <th>Hobi </th>
        <th>Jenis Kelamin</th>
        <th>Alamat</th>
        <th>No.Telepon</th>
        <th>Skil</th>
        <th>Pendidikan</th>
        <th>Pekerjaan</th>

        <th>Aksi</th>

    </tr>
    <?php
    $nomor= 1; 
    ?>
    <?php
    foreach ($cari as $cari2):
    ?>
     <tr>
        <td class="tabel-header1"><?= $nomor;?></td>
        <td class="tabel-header2"><?= $cari2 ['nama'];?></td>
        <td class="tabel-header4"><?= $cari2 ['hobi'];?></td>
        <td class="tabel-header3"><?php echo $cari2 ['jenis_kelamin'];?></td>
        <td class="tabel-header4"><?php echo $cari2 ['alamat'];?></td>
        <td class="tabel-header4"><?php echo $cari2 ['no_tlpn'];?></td>
        <td class="tabel-header4"><?php echo $cari2 ['skil'];?></td>
        <td class="tabel-header2"><?php echo $cari2 ['pendidikan'];?></td>
        <td class="tabel-header2"><?php echo $cari2 ['pekerjaan'];?></td>

        <td><a href="edit.php?no=<?= $cari2 ["no"]?>">Edit</a> |
            <a href="hapus.php?no=<?= $cari2 ["no"]?>">Hapus</a>
        </td>
    </tr>
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
  </table>

</body>
</html>