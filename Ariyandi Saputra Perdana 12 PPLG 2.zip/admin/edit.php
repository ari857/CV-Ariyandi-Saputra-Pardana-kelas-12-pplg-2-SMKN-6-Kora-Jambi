<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
$database= mysqli_connect('localhost','root','','toko');//menampilkan Nama database
$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT*FROM barang WHERE no=$hapus");

if(isset ($_POST["tombol"])){
    $kode = $_POST ["nama"];
    $hobi = $_POST ["hobi"];
    $nama = $_POST ["jenis_kelamin"];
    $jenis_kelamin = $_POST ["alamat"];
    $alamat = $_POST ["no_tlpn"];
    $jumlah = $_POST ["skil"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];


   
    $edit = "UPDATE barang SET
    nama = '$kode',
    hobi = '$hobi',
    jenis_kelamin = '$nama',
    alamat = '$jenis_kelamin',
    no_tlpn = '$alamat',
    skil = '$jumlah',
    pendidikan = '$pendidikan',
    pekerjaan = '$pekerjaan'
    WHERE no=$hapus";

    mysqli_query($database,$edit);
    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">Website Tugas</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        </ul>
    </div>
    <div class="konten">
<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Profil</h2>
    <form method="POST">
    <input type="hidden" name="no" value="<?= $cari ['no'];?>">
<ul>
    <li><label >Nama</label></li>
    <li><input type="text" name="nama" value="<?= $cari ['nama'];?>"></li>
    <li><label >Hobi</label></li>
    <li><textarea name="hobi" id=""><?= $cari ['hobi'];?></textarea></li>
    <li><label >Jenis Kelamin</label></li>
    <li><input type="text" name="jenis_kelamin" value="<?= $cari ['jenis_kelamin'];?>"></li>
    <li><label >Alamat</label></li>
    <li><input type="text" name="alamat" value="<?= $cari ['alamat'];?>"></li>
    <li><label >No.Telepon</label></li>
    <li><input type="text" name="no_tlpn" value="<?= $cari ["no_tlpn"];?>"></li>
    <li><label >Skil</label></li>
    <li><input type="text" name="skil" value="<?= $cari ["skil"];?>"></li>
    <li><label >Pendidikan</label></li>
    <li><textarea name="pendidikan" id=""><?= $cari ["pendidikan"];?></textarea></li>
    <li><label >Pekerjaan</label></li>
    <li><textarea name="pekerjaan" id=""><?= $cari ["pekerjaan"];?></textarea></li>


    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>